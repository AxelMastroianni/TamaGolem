package il.tama.golem;

import java.util.ArrayList;
import java.util.Random;

public class Giocatore {
	private String nome="";
	private ArrayList<TamaGolem> iMieiTamagolem=new ArrayList<TamaGolem>();
	private Random r=new Random();
	
	public Giocatore(String nome) {
		this.nome=nome;
	}
	
	public TamaGolem evocaTamaGolem() {
		return iMieiTamagolem.get(0);
	}
	
	public void aggiungiTamaGolem(String nome) {
		iMieiTamagolem.add(new TamaGolem(nome,TamaGolem.VITA_MASSIMA));
	}
	
	public boolean haiPerso() {
		if(iMieiTamagolem.isEmpty())
			return true;
		return false;
	}
	
	public TamaGolem getTamaGolem(int indice) {
		return iMieiTamagolem.get(indice);
	}
	
	public void rimuoviTamaGolem() {
		iMieiTamagolem.remove(0);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public int getNumeroTamaGolem() {
		return iMieiTamagolem.size();
	}

}
