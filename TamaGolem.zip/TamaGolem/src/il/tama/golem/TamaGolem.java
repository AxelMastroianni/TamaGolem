package il.tama.golem;

import java.util.ArrayList;

import il.tama.golem.Pietra.Elementi;

public class TamaGolem {
	public static final int VITA_MASSIMA=100;
	private String nome="";
	private ArrayList<Pietra> pietre=new ArrayList<Pietra>();
	Elementi element;
	private int vita=0;
	
	public TamaGolem(String nome, int vita) {
		this.nome=nome;
		this.vita=vita;
	}
	
	public TamaGolem(String nome) {
		this.nome=nome;
	}
	
	public Pietra attacca(int indice) {
		return pietre.get(indice);
	}
	public void subisci(int danno) {
		setVita(Math.max(vita-danno, 0));
	}
	
	public boolean sonoMorto() {
		if(vita==0)
			return true;
		return false;
	}
	
	public void aggiungiPietra(String nomePietra) {
		pietre.add(new Pietra(element.valueOf(nomePietra.toUpperCase()).ordinal()));
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public ArrayList<Pietra> getPietre() {
		return pietre;
	}

	public void setPietre(ArrayList<Pietra> pietre) {
		this.pietre = pietre;
	}

	public int getVita() {
		return vita;
	}

	public void setVita(int vita) {
		this.vita = vita;
	}

	public Elementi getElement() {
		return element;
	}

	public void setElement(Elementi element) {
		this.element = element;
	}
	
	

}
