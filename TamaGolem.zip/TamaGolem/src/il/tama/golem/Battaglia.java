package il.tama.golem;

import java.util.ArrayList;

public class Battaglia {
	private Giocatore giocatore1;
	private Giocatore giocatore2;
	private int numeroElementi=0;
	private Equilibrio tabellone;
	private int numeroPietre=0;
	private int numeroTamaGolem=0;
	private int scortaPietre=0;
	
	public Battaglia(Giocatore giocatore1, Giocatore giocatore2, int numeroElementi) {
		this.giocatore1=giocatore1;
		this.giocatore2=giocatore2;
		this.numeroElementi=numeroElementi;
		tabellone=new Equilibrio("Tentacolo",numeroElementi);
		tabellone.creaEquilibrio();
		numeroPietre=((numeroElementi+1)/3)+1;
		numeroTamaGolem=(numeroElementi-1)*(numeroElementi-2)/(2*numeroPietre);
		scortaPietre=((2*numeroTamaGolem*numeroPietre)/numeroElementi)*numeroElementi;
	}
	
	public Giocatore getGiocatore1() {
		return giocatore1;
	}

	public void setGiocatore1(Giocatore giocatore1) {
		this.giocatore1 = giocatore1;
	}

	public Giocatore getGiocatore2() {
		return giocatore2;
	}

	public void setGiocatore2(Giocatore giocatore2) {
		this.giocatore2 = giocatore2;
	}

	public int getNumeroElementi() {
		return numeroElementi;
	}

	public void setNumeroElementi(int numeroElementi) {
		this.numeroElementi = numeroElementi;
	}

	public Equilibrio getTabellone() {
		return tabellone;
	}

	public void setTabellone(Equilibrio tabellone) {
		this.tabellone = tabellone;
	}

	public int getNumeroPietre() {
		return numeroPietre;
	}

	public void setNumeroPietre(int numeroPietre) {
		this.numeroPietre = numeroPietre;
	}

	public int getNumeroTamaGolem() {
		return numeroTamaGolem;
	}

	public void setNumeroTamaGolem(int numeroTamaGolem) {
		this.numeroTamaGolem = numeroTamaGolem;
	}

	public int getScortaPietre() {
		return scortaPietre;
	}

	public void setScortaPietre(int scortaPietre) {
		this.scortaPietre = scortaPietre;
	}

	public void battlePhase(int indicePietra, TamaGolem tama1, TamaGolem tama2) {
		Pietra p1=tama1.attacca(indicePietra);
		Pietra p2=tama2.attacca(indicePietra);
		if(tabellone.chiVince(p1.getIndice(), p2.getIndice())) {
			int quantoPerde=tabellone.setPotenzaPietra(p1.getIndice(), p2.getIndice());
			tama2.subisci(quantoPerde);
			System.out.println("Il TamaGolem subisce un attacco "+tama1.getElement().values()[p1.getIndice()]);
			System.out.println("E perde "+quantoPerde);
			attendi(2);
		}
		else {
			int quantoPerde=tabellone.setPotenzaPietra(p2.getIndice(), p1.getIndice());
			tama1.subisci(quantoPerde);
			System.out.println("Il TamaGolem subisce un attacco "+tama2.getElement().values()[p2.getIndice()]);
			System.out.println("E perde "+quantoPerde);
			attendi(2);
		}
	}
	
	public boolean endPhaseGiocatore1() {
		if(giocatore1.getTamaGolem(0).sonoMorto()) {
			giocatore1.rimuoviTamaGolem();
			return true;
		}
		return false;	
	}
	public boolean endPhaseGiocatore2() {
		if(giocatore2.getTamaGolem(0).sonoMorto()) {
			giocatore2.rimuoviTamaGolem();
			return true;
		}
		return false;
	}
	
	public boolean sconfittaGicoatore1() {
		if(giocatore1.haiPerso())
			return true;
		return false;
	}
	public boolean sconfittaGiocatore2() {
		if(giocatore2.haiPerso())
			return true;
		return false;
	}
	public boolean stessePietre(ArrayList<Pietra>tama1, ArrayList<Pietra>tama2) {
		int contaUguali=0;
		for(int i=0;i<tama1.size();i++) {
			if(tama1.get(i).getIndice()==tama2.get(i).getIndice())
				contaUguali++;
		}
		if(contaUguali==tama1.size())
			return true;
		return false;
	}
	
	public void attendi(int secondi) {
		try {
			Thread.sleep(secondi*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
