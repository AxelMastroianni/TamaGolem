package il.tama.golem;

public class Pietra {
	public enum Elementi{ACQUA,ELETTRO,ERBA,FUOCO,PSICO,BUIO,VOLANTE,SPETTRO,COLEOTTERO,GHIACCIO};
	private int indice=0;
	
	public Pietra(int indice) {
		this.indice=indice;
	}
	public int getIndice() {
		return indice;
	}
	public void setIndice(int indice) {
		if(indice>0)
			this.indice = indice;
	}

}
