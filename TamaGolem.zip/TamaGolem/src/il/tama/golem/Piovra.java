package il.tama.golem;

import il.tama.golem.Pietra.Elementi;
import it.unibs.fp.mylib.InputDati;

public class Piovra {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Equilibrio e=new Equilibrio("Tentacolo",10);
		e.stampaEquilibrio();
		System.out.println();
		e.creaEquilibrio();
		e.stampaEquilibrio();
		Elementi element = null;
		String nomePietra=InputDati.leggiStringaNonVuota("Inserisci il nome della pietra: ");
		System.out.println(element.valueOf(nomePietra.toUpperCase()).ordinal());

	}

}
