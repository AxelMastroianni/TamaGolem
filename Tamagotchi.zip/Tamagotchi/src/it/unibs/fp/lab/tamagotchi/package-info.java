/**
 * 
 */
/**
 * @author User
 *
 */
package it.unibs.fp.lab.tamagotchi;