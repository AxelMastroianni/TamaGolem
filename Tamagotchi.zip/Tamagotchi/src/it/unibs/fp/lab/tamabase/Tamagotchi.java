package it.unibs.fp.lab.tamabase;
import java.util.*;
public class Tamagotchi {
	private Random r=new Random();
	private static final int AUMENTA = 1;
	public static enum Sessi{M,F,m,f}; //evita il controllo sul sesso
	private String nome="";
	private Sessi sesso;
	private int sazieta=50;
	private int soddisfazione=50;
	private static final int MAX_CAREZZE_BISCOTTI=20;
	private static final int DIMINUISCI_RAPPORTO=4;
	private static final int MAX_SATISFACTION_EAT=100;
	private static final int SOGLIA_FELICITA=75;
	private static final int SOGLIA_TRISTEZZA=30;
	public Tamagotchi(String nome)
	{
		this.nome=nome;
		this.sesso=Sessi.values()[Math.abs(r.nextInt()%Sessi.values().length)]; //sesso estratto a caso
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Sessi getSesso() {
		return sesso;
	}
	public void setSesso(Sessi sesso) {
		this.sesso = sesso;
	}
	public int getSazieta() {
		return sazieta;
	}
	public int getSoddisfazione() {
		return soddisfazione;
	}
	//inizia l'interazione con la bestia
	
	public void daiBiscotti(int quantiBiscotti)
	{
		aumentaSazieta(quantiBiscotti);
		quantiBiscotti=Math.min(quantiBiscotti, MAX_CAREZZE_BISCOTTI);//non rischi di dargliene pi� di 20
		if(quantiBiscotti/DIMINUISCI_RAPPORTO!=0)
			diminuisciSoddisfazione(quantiBiscotti);
	}
	public void faiCarezze(int quanteCarezze)
	{
		quanteCarezze=Math.min(quanteCarezze, MAX_CAREZZE_BISCOTTI); //non gliene dai pi� di 20
		aumentaSoddisfazione(quanteCarezze);
		if(quanteCarezze/DIMINUISCI_RAPPORTO!=0)
			diminuisciSazieta(quanteCarezze);
	}
	
	
	private void aumentaSazieta(int quantiBiscotti)
	{
		sazieta=Math.min(sazieta+AUMENTA*quantiBiscotti,MAX_SATISFACTION_EAT);//non va oltre 100
	}
	private void aumentaSoddisfazione(int quanteCarezze)
	{
		soddisfazione=Math.min(soddisfazione+AUMENTA*quanteCarezze, MAX_SATISFACTION_EAT);//non va oltre 100
	}
	
	
	private void diminuisciSazieta(int quanteCarezze)
	{
			sazieta=Math.max(sazieta-(quanteCarezze/DIMINUISCI_RAPPORTO),0); //non va sotto zero
	}
	private void diminuisciSoddisfazione(int quantiBiscotti)
	{
			soddisfazione=Math.max(soddisfazione-(quantiBiscotti/DIMINUISCI_RAPPORTO),0); //non va sotto zero
	}
	
	
	public boolean controllaSazieta()
	{
		if(sazieta>=MAX_SATISFACTION_EAT)
			return true;
		return false;
	}
	public boolean controllaSoddisfazione()
	{
		if(soddisfazione>=MAX_SATISFACTION_EAT)
			return true;
		return false;
	}
	
	
	public boolean verificaFelicita()
	{
		if(sazieta>SOGLIA_FELICITA && soddisfazione>SOGLIA_FELICITA)
			return true;
		return false;
	}
	public boolean verificaTristezza()
	{
		if(sazieta<SOGLIA_TRISTEZZA || soddisfazione<SOGLIA_TRISTEZZA)
			return true;
		return false;
	}

}
